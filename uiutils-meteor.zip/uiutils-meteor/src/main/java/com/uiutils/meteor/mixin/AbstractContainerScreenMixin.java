package com.uiutils.meteor.mixin;

import com.uiutils.meteor.FabricateScreen;
import com.uiutils.meteor.ScreenUtil;
import com.uiutils.meteor.UiUtilsModule;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractContainerScreen.class)
public abstract class AbstractContainerScreenMixin extends Screen {
    @Shadow protected int leftPos;
    @Shadow protected int imageWidth;

    @Unique private static final Identifier UIUTILS_FRAME = Identifier.fromNamespaceAndPath("uiutils", "textures/gui/frame.png");
    // Size of frame.png in GUI pixels (drawn 1:1).
    @Unique private static final int PW = 130, PH = 168;
    @Unique private EditBox uiutils$chat;

    protected AbstractContainerScreenMixin(Component title) {
        super(title);
    }

    @Inject(method = "init()V", at = @At("TAIL"))
    private void uiutils$init(CallbackInfo ci) {
        uiutils$chat = null;
        if (!Modules.get().isActive(UiUtilsModule.class)) return;

        // Left of the GUI, else right of it, else clamp on screen.
        int x = leftPos - PW - 4;
        if (x < 2) x = leftPos + imageWidth + 4;
        x = Math.max(2, Math.min(x, width - PW - 2));
        int y = Math.max(2, (height - PH) / 2);
        final int fx = x, fy = y;

        addRenderableOnly((g, mx, my, d) -> {
            g.blit(RenderPipelines.GUI_TEXTURED, UIUTILS_FRAME, fx, fy, 0f, 0f, PW, PH, PW, PH);
            g.text(font, "UI Utils", fx + 8, fy + 3, 0xFF202020, false);
        });

        int ix = x + 5, iw = PW - 10, ry = y + 18, step = 20;

        btn("Close w/o packet", ix, ry, iw, b -> UiUtilsModule.closeWithoutPacket());
        btn("Delay packets: " + (UiUtilsModule.isDelaying() ? "ON" : "OFF"), ix, ry + step, iw, b -> {
            UiUtilsModule.toggleDelay();
            b.setMessage(Component.literal("Delay packets: " + (UiUtilsModule.isDelaying() ? "ON" : "OFF")));
        });
        btn("Leave & send packets", ix, ry + step * 2, iw, b -> UiUtilsModule.leaveAndSend());
        btn("Fabricate packet", ix, ry + step * 3, iw, b -> ScreenUtil.set(new FabricateScreen(this)));
        btn("De-sync", ix, ry + step * 4, iw, b -> UiUtilsModule.desync());

        int half = (iw - 4) / 2;
        btn("Save GUI", ix, ry + step * 5, half, b -> UiUtilsModule.saveGui());
        btn("Load GUI", ix + half + 4, ry + step * 5, half, b -> UiUtilsModule.loadGui());

        uiutils$chat = addRenderableWidget(new EditBox(font, ix, ry + step * 6, iw, 16, Component.literal("Chat")));
        uiutils$chat.setMaxLength(256);
        uiutils$chat.setHint(Component.literal("Chat / command (Enter)"));
    }

    @Unique
    private void btn(String label, int x, int y, int w, Button.OnPress action) {
        addRenderableWidget(Button.builder(Component.literal(label), action).bounds(x, y, w, 16).build());
    }

    // While typing in the chatbox, keys must not reach the container (E closes it, 1-9 swap slots, Q drops).
    @Inject(method = "keyPressed(Lnet/minecraft/client/input/KeyEvent;)Z", at = @At("HEAD"), cancellable = true)
    private void uiutils$keyPressed(KeyEvent event, CallbackInfoReturnable<Boolean> cir) {
        if (uiutils$chat == null || !uiutils$chat.isFocused()) return;

        int key = event.key();
        if (key == 256) {
            uiutils$chat.setFocused(false); // first Esc leaves the box, second closes the GUI
        } else if (key == 257 || key == 335) {
            UiUtilsModule.sendChat(uiutils$chat.getValue());
            uiutils$chat.setValue("");
        } else {
            uiutils$chat.keyPressed(event);
        }
        cir.setReturnValue(true);
    }
}
