package com.uiutils.meteor.mixin;

import com.uiutils.meteor.FabricateScreen;
import com.uiutils.meteor.ScreenUtil;
import com.uiutils.meteor.UiUtilsModule;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import java.util.ArrayList;
import java.util.List;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractContainerScreen.class)
public abstract class AbstractContainerScreenMixin extends Screen {
    @Shadow protected int leftPos;
    @Shadow protected int imageWidth;

    @Unique private static final Identifier UIUTILS_FRAME = Identifier.fromNamespaceAndPath("uiutils", "textures/gui/frame.png");
    // Size of frame.png in GUI pixels (drawn 1:1).
    @Unique private static final int PW = 130, PH = 168;
    @Unique private static final int HEADER = 14; // draggable strip at the top of the frame
    // Panel position survives closing/reopening the GUI (reset only when the game restarts).
    @Unique private static boolean uiutils$placed;
    @Unique private static int uiutils$px, uiutils$py;

    @Unique private EditBox uiutils$chat;
    @Unique private final List<AbstractWidget> uiutils$parts = new ArrayList<>();
    @Unique private final List<int[]> uiutils$offsets = new ArrayList<>(); // each part's offset from the panel corner
    @Unique private boolean uiutils$dragging;
    @Unique private int uiutils$grabX, uiutils$grabY;

    protected AbstractContainerScreenMixin(Component title) {
        super(title);
    }

    @Inject(method = "init()V", at = @At("TAIL"))
    private void uiutils$init(CallbackInfo ci) {
        uiutils$chat = null;
        uiutils$dragging = false;
        uiutils$parts.clear();
        uiutils$offsets.clear();
        if (!Modules.get().isActive(UiUtilsModule.class)) return;

        if (!uiutils$placed) {
            // First time: left of the GUI, else right of it.
            int x = leftPos - PW - 4;
            if (x < 2) x = leftPos + imageWidth + 4;
            uiutils$px = x;
            uiutils$py = (height - PH) / 2;
            uiutils$placed = true;
        }
        // Window may have been resized since the last time.
        uiutils$px = Math.max(0, Math.min(uiutils$px, width - PW));
        uiutils$py = Math.max(0, Math.min(uiutils$py, height - PH));
        int x = uiutils$px, y = uiutils$py;

        addRenderableOnly((g, mx, my, d) -> {
            g.blit(RenderPipelines.GUI_TEXTURED, UIUTILS_FRAME, uiutils$px, uiutils$py, 0f, 0f, PW, PH, PW, PH);
            g.text(font, "UI Utils (drag here)", uiutils$px + 8, uiutils$py + 3, 0xFF202020, false);
        });

        int ix = x + 5, iw = PW - 10, ry = y + 18, step = 20;

        btn("Close w/o packet", ix, ry, iw, b -> UiUtilsModule.closeWithoutPacket());
        btn("Delay packets: " + (UiUtilsModule.isDelaying() ? "ON" : "OFF"), ix, ry + step, iw, b -> {
            UiUtilsModule.toggleDelay();
            b.setMessage(Component.literal("Delay packets: " + (UiUtilsModule.isDelaying() ? "ON" : "OFF")));
        });
        btn("Leave & send packets", ix, ry + step * 2, iw, b -> UiUtilsModule.leaveAndSend());
        btn("Fabricate packet", ix, ry + step * 3, iw, b -> ScreenUtil.set(new FabricateScreen(this)));
        btn("De-sync", ix, ry + step * 4, iw, b -> UiUtilsModule.desync());

        int half = (iw - 4) / 2;
        btn("Save GUI", ix, ry + step * 5, half, b -> UiUtilsModule.saveGui());
        btn("Load GUI", ix + half + 4, ry + step * 5, half, b -> UiUtilsModule.loadGui());

        uiutils$chat = addRenderableWidget(new EditBox(font, ix, ry + step * 6, iw, 16, Component.literal("Chat")));
        uiutils$chat.setMaxLength(256);
        uiutils$chat.setHint(Component.literal("Chat / command (Enter)"));
        track(uiutils$chat);
    }

    @Unique
    private void btn(String label, int x, int y, int w, Button.OnPress action) {
        track(addRenderableWidget(Button.builder(Component.literal(label), action).bounds(x, y, w, 16).build()));
    }

    @Unique
    private void track(AbstractWidget w) {
        uiutils$parts.add(w);
        uiutils$offsets.add(new int[]{w.getX() - uiutils$px, w.getY() - uiutils$py});
    }

    @Unique
    private boolean uiutils$inHeader(double mx, double my) {
        return !uiutils$parts.isEmpty() && mx >= uiutils$px && mx < uiutils$px + PW
            && my >= uiutils$py && my < uiutils$py + HEADER;
    }

    @Inject(method = "mouseClicked(Lnet/minecraft/client/input/MouseButtonEvent;Z)Z", at = @At("HEAD"), cancellable = true)
    private void uiutils$mouseClicked(MouseButtonEvent event, boolean doubleClick, CallbackInfoReturnable<Boolean> cir) {
        if (event.button() == 0 && uiutils$inHeader(event.x(), event.y())) {
            uiutils$dragging = true;
            uiutils$grabX = (int) event.x() - uiutils$px;
            uiutils$grabY = (int) event.y() - uiutils$py;
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "mouseDragged(Lnet/minecraft/client/input/MouseButtonEvent;DD)Z", at = @At("HEAD"), cancellable = true)
    private void uiutils$mouseDragged(MouseButtonEvent event, double dx, double dy, CallbackInfoReturnable<Boolean> cir) {
        if (!uiutils$dragging) return;
        uiutils$px = Math.max(0, Math.min((int) event.x() - uiutils$grabX, width - PW));
        uiutils$py = Math.max(0, Math.min((int) event.y() - uiutils$grabY, height - PH));
        for (int i = 0; i < uiutils$parts.size(); i++) {
            uiutils$parts.get(i).setX(uiutils$px + uiutils$offsets.get(i)[0]);
            uiutils$parts.get(i).setY(uiutils$py + uiutils$offsets.get(i)[1]);
        }
        cir.setReturnValue(true);
    }

    @Inject(method = "mouseReleased(Lnet/minecraft/client/input/MouseButtonEvent;)Z", at = @At("HEAD"), cancellable = true)
    private void uiutils$mouseReleased(MouseButtonEvent event, CallbackInfoReturnable<Boolean> cir) {
        if (uiutils$dragging) {
            uiutils$dragging = false;
            cir.setReturnValue(true);
        }
    }

    // While typing in the chatbox, keys must not reach the container (E closes it, 1-9 swap slots, Q drops).
    @Inject(method = "keyPressed(Lnet/minecraft/client/input/KeyEvent;)Z", at = @At("HEAD"), cancellable = true)
    private void uiutils$keyPressed(KeyEvent event, CallbackInfoReturnable<Boolean> cir) {
        if (uiutils$chat == null || !uiutils$chat.isFocused()) return;

        int key = event.key();
        if (key == 256) {
            uiutils$chat.setFocused(false); // first Esc leaves the box, second closes the GUI
        } else if (key == 257 || key == 335) {
            UiUtilsModule.sendChat(uiutils$chat.getValue());
            uiutils$chat.setValue("");
        } else {
            uiutils$chat.keyPressed(event);
        }
        cir.setReturnValue(true);
    }
}
