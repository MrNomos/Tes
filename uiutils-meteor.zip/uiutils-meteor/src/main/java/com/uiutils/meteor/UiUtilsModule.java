package com.uiutils.meteor;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundContainerButtonClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;
import net.minecraft.world.inventory.AbstractContainerMenu;

import java.util.ArrayList;
import java.util.List;

/** UI Utils: the panel itself is added by AbstractContainerScreenMixin; this holds state + actions. */
public class UiUtilsModule extends Module {
    private static final Minecraft mc = Minecraft.getInstance();

    private static final List<Packet<?>> queue = new ArrayList<>();
    private static boolean delay;
    private static boolean flushing;

    private static Screen savedScreen;
    private static AbstractContainerMenu savedMenu;
    private static ClientPacketListener savedConnection;

    public UiUtilsModule() {
        super(Categories.Misc, "ui-utils", "Shows a UI Utils panel (packet/GUI tools) next to inventories and containers.");
    }

    @Override
    public void onDeactivate() {
        delay = false;
        queue.clear();
    }

    // Only container packets are delayed, same as the original UI-Utils.
    @EventHandler
    private void onSend(PacketEvent.Send event) {
        if (!delay || flushing) return;
        Packet<?> p = event.packet;
        if (p instanceof ServerboundContainerClickPacket
            || p instanceof ServerboundContainerButtonClickPacket
            || p instanceof ServerboundContainerClosePacket) {
            queue.add(p);
            event.cancel();
        }
    }

    public static boolean isDelaying() { return delay; }
    public static int queued() { return queue.size(); }

    /** Closes the screen client-side only; the server never gets the close packet. */
    public static void closeWithoutPacket() {
        mc.setScreen(null);
    }

    /** Tells the server the container is closed while the screen stays open. */
    public static void desync() {
        if (mc.player == null || mc.getConnection() == null) return;
        mc.getConnection().send(new ServerboundContainerClosePacket(mc.player.containerMenu.containerId));
    }

    public static void toggleDelay() {
        delay = !delay;
        if (!delay) flush();
        ChatUtils.info("Delay packets: " + (delay ? "ON" : "OFF"));
    }

    private static int flush() {
        ClientPacketListener c = mc.getConnection();
        int n = queue.size();
        if (c != null) {
            flushing = true;
            try {
                for (Packet<?> p : queue) c.send(p);
            } finally {
                flushing = false;
            }
        }
        queue.clear();
        return n;
    }

    public static void leaveAndSend() {
        ClientPacketListener c = mc.getConnection();
        if (c == null) return;
        int n = flush();
        delay = false;
        c.getConnection().disconnect(Component.literal("Left via UI Utils (sent " + n + " packets)"));
    }

    public static void saveGui() {
        if (mc.player == null || mc.screen == null) return;
        savedScreen = mc.screen;
        savedMenu = mc.player.containerMenu;
        savedConnection = mc.getConnection();
        ChatUtils.info("GUI saved.");
    }

    public static void loadGui() {
        // A saved GUI from another server/world session would be bogus.
        if (savedScreen == null || mc.player == null || savedConnection != mc.getConnection()) {
            ChatUtils.info("No saved GUI for this session.");
            return;
        }
        mc.player.containerMenu = savedMenu;
        mc.setScreen(savedScreen);
    }

    public static void sendChat(String text) {
        String t = text.trim();
        ClientPacketListener c = mc.getConnection();
        if (t.isEmpty() || c == null) return;
        if (t.startsWith("/")) c.sendCommand(t.substring(1));
        else c.sendChat(t);
    }
}
