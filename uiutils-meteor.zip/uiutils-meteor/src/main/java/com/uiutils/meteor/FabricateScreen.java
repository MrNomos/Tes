package com.uiutils.meteor;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.HashedStack;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundContainerButtonClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;

/** Builds a click-slot or button-click packet for the currently open menu and sends it. */
public class FabricateScreen extends Screen {
    private static final ContainerInput[] TYPES = {
        ContainerInput.PICKUP, ContainerInput.QUICK_MOVE, ContainerInput.SWAP, ContainerInput.CLONE,
        ContainerInput.THROW, ContainerInput.QUICK_CRAFT, ContainerInput.PICKUP_ALL
    };

    private final Screen parent;
    private EditBox slot, button;
    private int type;

    public FabricateScreen(Screen parent) {
        super(Component.literal("Fabricate packet"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2, y = height / 2 - 55;

        slot = addRenderableWidget(new EditBox(font, cx - 60, y, 120, 18, Component.literal("Slot")));
        slot.setValue("0");
        button = addRenderableWidget(new EditBox(font, cx - 60, y + 36, 120, 18, Component.literal("Button")));
        button.setValue("0");

        addRenderableWidget(Button.builder(Component.literal("Type: " + TYPES[type]), b -> {
            type = (type + 1) % TYPES.length;
            b.setMessage(Component.literal("Type: " + TYPES[type]));
        }).bounds(cx - 60, y + 60, 120, 18).build());

        addRenderableWidget(Button.builder(Component.literal("Send click-slot"), b -> sendClick())
            .bounds(cx - 60, y + 82, 120, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Send button-click"), b -> sendButton())
            .bounds(cx - 60, y + 104, 120, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose())
            .bounds(cx - 60, y + 130, 120, 18).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        int cx = width / 2, y = height / 2 - 55;
        g.centeredText(font, title, cx, y - 20, 0xFFFFFFFF);
        g.text(font, "Slot", cx - 60, y - 10, 0xFFAAAAAA);
        g.text(font, "Button / id", cx - 60, y + 26, 0xFFAAAAAA);
    }

    private void sendClick() {
        AbstractContainerMenu menu = minecraft.player.containerMenu;
        Integer s = parse(slot), b = parse(button);
        if (s == null || b == null) return;
        send(new ServerboundContainerClickPacket(menu.containerId, menu.getStateId(), (short) (int) s,
            (byte) (int) b, TYPES[type], new Int2ObjectOpenHashMap<HashedStack>(), HashedStack.EMPTY));
    }

    private void sendButton() {
        Integer b = parse(button);
        if (b == null) return;
        send(new ServerboundContainerButtonClickPacket(minecraft.player.containerMenu.containerId, b));
    }

    // Goes through the connection, so the module's "Delay packets" applies to it too.
    private void send(net.minecraft.network.protocol.Packet<?> p) {
        if (Minecraft.getInstance().getConnection() != null) Minecraft.getInstance().getConnection().send(p);
    }

    private static Integer parse(EditBox box) {
        try {
            return Integer.parseInt(box.getValue().trim());
        } catch (NumberFormatException e) {
            ChatUtils.info("Invalid number: " + box.getValue());
            return null;
        }
    }

    @Override
    public void onClose() {
        ScreenUtil.set(parent);
    }
}
