package com.uiutils.meteor;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

import java.lang.reflect.Method;

/** In 26.3 screen handling lives on mc.gui; reflection (like the original UI-Utils) survives renames. */
public final class ScreenUtil {
    private ScreenUtil() {}

    public static Screen get() {
        Object gui = Minecraft.getInstance().gui;
        for (Method m : gui.getClass().getMethods()) {
            if (m.getParameterCount() == 0 && Screen.class.isAssignableFrom(m.getReturnType())
                && (m.getName().equals("screen") || m.getName().equals("getScreen"))) {
                try {
                    return (Screen) m.invoke(gui);
                } catch (ReflectiveOperationException e) {
                    throw new IllegalStateException("Could not read the active screen", e);
                }
            }
        }
        throw new IllegalStateException("No screen getter on Gui");
    }

    public static void set(Screen screen) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            try {
                mc.gui.getClass().getMethod("setScreen", Screen.class).invoke(mc.gui, screen);
            } catch (ReflectiveOperationException e) {
                throw new IllegalStateException("Could not change the active screen", e);
            }
        });
    }
}
