package com.uiutils.meteor;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;

import java.lang.invoke.MethodHandles;

public class UiUtilsAddon extends MeteorAddon {
    @Override
    public void onInitialize() {
        // Lets orbit reach @EventHandler methods in this package.
        MeteorClient.EVENT_BUS.registerLambdaFactory("com.uiutils.meteor",
            (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));

        Modules.get().add(new UiUtilsModule());
    }

    @Override
    public String getPackage() {
        return "com.uiutils.meteor";
    }
}
