package autismclient.util.oresim;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;

import java.util.function.IntPredicate;

/**
 * OreSim worldgen simulation is disabled in the 26.3 port: Minecraft 26.3 rewrote the worldgen
 * Feature system (Feature is now an interface, ConfiguredFeature/FeatureConfiguration are gone), which
 * the old synthetic-generation engine depended on. This stub keeps the public API so the rest of the
 * client compiles; it never simulates anything and always reports "no data".
 */
public final class AutismOreSimEngine {
    public static final int MAX_SIM_RADIUS = 8;

    private AutismOreSimEngine() {
    }

    public enum Status {
        IDLE,
        LOADING_CONTEXT,
        GENERATING,
        READY,
        UNVERIFIED_WORLDGEN,
        UNSUPPORTED_DIMENSION,
        ERROR
    }

    public record TargetProgress(long loadId, int completedChunks, int totalChunks) {
        public TargetProgress {
            totalChunks = Math.max(0, totalChunks);
            completedChunks = Math.max(0, Math.min(completedChunks, totalChunks));
        }

        public double fraction() {
            return totalChunks == 0 ? 0.0 : completedChunks / (double) totalChunks;
        }

        public boolean complete() {
            return totalChunks > 0 && completedChunks >= totalChunks;
        }
    }

    @FunctionalInterface
    public interface PositionJudge {
        boolean shouldDrop(int stateId, long packedPos);
    }

    public static Status status() { return Status.IDLE; }
    public static boolean ready() { return false; }
    public static boolean loading() { return false; }
    public static boolean failed() { return false; }
    public static String failureMessage() { return ""; }
    public static int chunkCount() { return 0; }
    public static TargetProgress targetProgress() { return new TargetProgress(0L, 0, 0); }
    public static int storedPositions() { return 0; }
    public static boolean capped() { return false; }
    public static int revision() { return 0; }
    public static void clear() { }
    public static void suspend() { }
    public static void resume() { }
    public static boolean isSuspended() { return false; }
    public static boolean expireSuspended(long retentionNanos) { return false; }
    public static void forgetDisproven() { }
    public static void tick(ClientLevel level, BlockPos playerPos, Long worldSeed, int radius, int enabledMask) { }
    public static boolean selectionTruncated() { return false; }

    public static int selectNearest(double eyeX, double eyeY, double eyeZ, int radius,
                                    IntPredicate stateAllowed, int cap, long[] outPos, int[] outState) {
        return 0;
    }

    public static void collectNear(BlockPos center, int blockRadius, LongOpenHashSet out) { }
    public static void verifyNear(BlockPos center, int blockRadius, PositionJudge judge) { }
    public static int accuracyPercent() { return -1; }
}
