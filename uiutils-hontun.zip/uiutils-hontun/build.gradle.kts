// Unverified offline: plugin id/version follow Fabric's unobfuscated (26.x) Loom. Adjust to match your Meteor template if Gradle complains.
plugins {
    id("net.fabricmc.fabric-loom") version "1.16-SNAPSHOT"
}

version = "1.0.0"
group = "uiutils.hontun"

repositories {
    maven("https://maven.fabricmc.net/")
}

dependencies {
    minecraft("com.mojang:minecraft:${property("minecraft_version")}")
    implementation("net.fabricmc:fabric-loader:${property("loader_version")}")
    // Put your meteor-client-26_3.jar (the one that bundles Hontun) into libs/
    implementation(files("libs/meteor-client-26_3.jar"))
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}

tasks.processResources {
    inputs.property("version", project.version)
    filesMatching("fabric.mod.json") { expand("version" to project.version) }
}
