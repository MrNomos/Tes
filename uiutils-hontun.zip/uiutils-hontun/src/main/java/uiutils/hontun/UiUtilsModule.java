package uiutils.hontun;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.orbit.EventPriority;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.HashedStack;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundContainerButtonClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;

import java.util.ArrayList;
import java.util.List;

import static meteordevelopment.meteorclient.MeteorClient.mc;

/** UI Utils logic as a Meteor module. The Hontun theme styles the module settings and the vanilla panel buttons. */
public class UiUtilsModule extends Module {
    public static UiUtilsModule I;

    public boolean sendPackets = true, delayPackets = false;
    public int spam = 1;
    public final List<Packet<?>> queue = new ArrayList<>();

    private boolean bypass; // our own sends must skip the filter below
    private Screen savedScreen;
    private AbstractContainerMenu savedMenu;

    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> chat = sg.add(new BoolSetting.Builder()
        .name("chat-feedback").description("Print what each button did.").defaultValue(true).build());

    public UiUtilsModule() {
        super(Categories.Misc, "ui-utils", "Packet and GUI tools for container screens (close/desync, delay queue, fabricate, save/load GUI).");
        I = this;
    }

    @Override
    public void onDeactivate() {
        sendPackets = true;
        delayPackets = false;
        queue.clear();
    }

    @EventHandler
    private void onGameLeft(GameLeftEvent e) {
        queue.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post e) {
        Panel.refresh();
    }

    // UI packets = container click + button click, same as the original UI Utils.
    @EventHandler(priority = EventPriority.HIGHEST)
    private void onSend(PacketEvent.Send e) {
        if (bypass) return;
        if (!(e.packet instanceof ServerboundContainerClickPacket || e.packet instanceof ServerboundContainerButtonClickPacket)) return;
        if (!sendPackets) e.cancel();
        else if (delayPackets) {
            queue.add(e.packet);
            e.cancel();
        }
    }

    // ---- actions ----

    public void closeWithoutPacket() {
        mc.gui.setScreen(null);
        say("Closed GUI without packet");
    }

    public void desync() {
        if (mc.player == null || mc.getConnection() == null) return;
        mc.getConnection().send(new ServerboundContainerClosePacket(mc.player.containerMenu.containerId));
        say("Sent close packet, GUI kept open");
    }

    public void toggleSend() {
        sendPackets = !sendPackets;
        say("Send packets: " + sendPackets);
    }

    public void toggleDelay() {
        delayPackets = !delayPackets;
        if (!delayPackets) {
            say("Sent " + flush(1) + " delayed packet(s)");
            queue.clear();
        }
        say("Delay packets: " + delayPackets);
    }

    /** Sends the whole queue {@code times} times and leaves it intact. */
    public int flush(int times) {
        int n = 0;
        for (int i = 0; i < times; i++) for (Packet<?> p : new ArrayList<>(queue)) { raw(p); n++; }
        return n;
    }

    public void leaveAndSend() {
        if (mc.getConnection() == null) return;
        delayPackets = false;
        flush(1);
        queue.clear();
        disconnect();
    }

    public void disconnect() {
        if (mc.getConnection() != null) mc.getConnection().getConnection().disconnect(Component.literal("Disconnected by UI Utils"));
    }

    public void sendQueue() { // "Spam (xN)": queue stays so it can be spammed again
        say("Sent " + flush(spam) + " packet(s)");
    }

    public void sendOne() {
        if (queue.isEmpty()) { say("Queue is empty"); return; }
        raw(queue.remove(0));
        say("Sent one queued packet");
    }

    public void popLast() {
        if (queue.isEmpty()) { say("Queue is empty"); return; }
        queue.remove(queue.size() - 1);
        say("Removed last queued packet");
    }

    public void clearQueue() {
        say("Cleared " + queue.size() + " packet(s)");
        queue.clear();
    }

    public void resyncInventory() {
        if (mc.player == null || mc.getConnection() == null) return;
        AbstractContainerMenu m = mc.player.containerMenu;
        raw(new ServerboundContainerClickPacket(m.containerId, (m.getStateId() + 1) & 0x7FFF, (short) -1, (byte) 0,
            ContainerInput.PICKUP, new Int2ObjectArrayMap<>(),
            HashedStack.create(m.getCarried(), mc.getConnection().decoratedHashOpsGenenerator())));
        say("Requested inventory resync");
    }

    public void copyTitleJson() {
        if (mc.gui.screen() == null) return;
        JsonElement json = ComponentSerialization.CODEC.encodeStart(JsonOps.INSTANCE, mc.gui.screen().getTitle()).result().orElse(null);
        if (json == null) { say("Could not encode title"); return; }
        mc.keyboardHandler.setClipboard(new Gson().toJson(json));
        say("Copied GUI title JSON");
    }

    public void saveGui() {
        if (mc.gui.screen() == null || mc.player == null) return;
        savedScreen = mc.gui.screen();
        savedMenu = mc.player.containerMenu;
        say("Saved GUI");
    }

    public void loadGui() {
        if (savedScreen == null || mc.player == null) { say("No saved GUI"); return; }
        mc.gui.setScreen(savedScreen);
        mc.player.containerMenu = savedMenu;
        say("Loaded GUI");
    }

    /** Sends past the filter, e.g. fabricated packets the user explicitly asked to send. */
    public void raw(Packet<?> p) {
        if (mc.getConnection() == null) return;
        bypass = true;
        try { mc.getConnection().send(p); } finally { bypass = false; }
    }

    private void say(String s) {
        if (chat.get()) info(s);
    }
}
