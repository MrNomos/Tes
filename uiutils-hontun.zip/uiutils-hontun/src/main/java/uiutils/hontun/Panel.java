package uiutils.hontun;

import meteordevelopment.meteorclient.gui.GuiThemes;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;

import static meteordevelopment.meteorclient.MeteorClient.mc;

/** The button column from the UI Utils screenshot. Plain vanilla Buttons: Hontun restyles them. */
public final class Panel {
    private static Button sync, send, delay, queue, spam;

    private Panel() {}

    public static void build(Consumer<Button> add) {
        UiUtilsModule m = UiUtilsModule.I;
        if (m == null || !m.isActive()) return;

        int x = 4, y = 4, w = 118, h = 16, g = 2, half = (w - g) / 2, third = (w - 2 * g) / 3;
        sync = btn(x, y, w, h, () -> {}, add);
        sync.active = false;
        y += h + g;
        btn("Close without packet", x, y, w, h, m::closeWithoutPacket, add); y += h + g;
        btn("Desync", x, y, w, h, m::desync, add); y += h + g;
        send = btn(x, y, w, h, m::toggleSend, add); y += h + g;
        delay = btn(x, y, w, h, m::toggleDelay, add); y += h + g;
        btn("Leave & Send Packets", x, y, w, h, m::leaveAndSend, add); y += h + g;
        btn("Fabricate packet", x, y, w, h, () -> mc.gui.setScreen(new FabricateScreen(GuiThemes.get())), add); y += h + g;
        btn("Copy GUI Title JSON", x, y, w, h, m::copyTitleJson, add); y += h + g;
        btn("Save GUI", x, y, half, h, m::saveGui, add);
        btn("Load GUI", x + half + g, y, half, h, m::loadGui, add); y += h + g;
        btn("Clear Queue", x, y, half, h, m::clearQueue, add);
        queue = btn(x + half + g, y, half, h, () -> {}, add);
        queue.active = false;
        y += h + g;
        btn("Resync Inv", x, y, half, h, m::resyncInventory, add);
        btn("Disconnect", x + half + g, y, half, h, m::disconnect, add); y += h + g;
        btn("-", x, y, third / 2, h, () -> { m.spam = Math.max(1, m.spam - 1); refresh(); }, add);
        spam = btn(x + third / 2 + g, y, w - third - 2 * g, h, m::sendQueue, add);
        btn("+", x + w - third / 2, y, third / 2, h, () -> { m.spam = Math.min(100, m.spam + 1); refresh(); }, add); y += h + g;
        btn("Send One", x, y, half, h, m::sendOne, add);
        btn("Pop Last", x + half + g, y, half, h, m::popLast, add);
        refresh();
    }

    /** Called every tick; labels only change when state does, and stale buttons are harmless. */
    public static void refresh() {
        UiUtilsModule m = UiUtilsModule.I;
        if (m == null || sync == null || mc.player == null) return;
        sync.setMessage(Component.literal("Sync: " + mc.player.containerMenu.containerId + "  Rev: " + mc.player.containerMenu.getStateId()));
        send.setMessage(Component.literal("Send packets: " + m.sendPackets));
        delay.setMessage(Component.literal("Delay packets: " + m.delayPackets));
        queue.setMessage(Component.literal("Queue: " + m.queue.size()));
        spam.setMessage(Component.literal("Spam (x" + m.spam + ")"));
    }

    private static Button btn(String label, int x, int y, int w, int h, Runnable r, Consumer<Button> add) {
        Button b = Button.builder(Component.literal(label), bb -> r.run()).bounds(x, y, w, h).build();
        add.accept(b);
        return b;
    }

    private static Button btn(int x, int y, int w, int h, Runnable r, Consumer<Button> add) {
        return btn("", x, y, w, h, r, add);
    }
}
