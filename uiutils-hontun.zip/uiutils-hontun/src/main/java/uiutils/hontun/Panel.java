package uiutils.hontun;

import meteordevelopment.meteorclient.gui.GuiThemes;
import com.mojang.brigadier.suggestion.Suggestion;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import static meteordevelopment.meteorclient.MeteorClient.mc;

/** The button column from the UI Utils screenshot. Plain vanilla Buttons: Hontun restyles them. */
public final class Panel {
    private static Button sync, send, delay, queue, spam;
    private static EditBox chat;
    private static Consumer<AbstractWidget> adder;
    private static Consumer<AbstractWidget> remover;
    private static List<Button> sug = new ArrayList<>();
    private static final List<String> history = new ArrayList<>(); // session only
    private static int hi;
    private static List<Suggestion> shown = List.of();

    private Panel() {}

    public static void build(Consumer<AbstractWidget> add, Consumer<AbstractWidget> remove) {
        UiUtilsModule m = UiUtilsModule.I;
        if (m == null || !m.isActive()) return;
        adder = add;
        remover = remove;
        shown = List.of();
        sug = new ArrayList<>(); // old buttons belonged to the previous screen

        int x = 4, y = 4, w = 150, h = 16, g = 2, half = (w - g) / 2, third = (w - 2 * g) / 3;
        sync = btn(x, y, w, h, () -> {}, add);
        sync.active = false;
        y += h + g;
        btn("Close without packet", x, y, w, h, m::closeWithoutPacket, add); y += h + g;
        btn("Desync", x, y, w, h, m::desync, add); y += h + g;
        send = btn(x, y, w, h, m::toggleSend, add); y += h + g;
        delay = btn(x, y, w, h, m::toggleDelay, add); y += h + g;
        btn("Leave & Send Packets", x, y, w, h, m::leaveAndSend, add); y += h + g;
        btn("Fabricate packet", x, y, w, h, () -> mc.gui.setScreen(new FabricateScreen(GuiThemes.get())), add); y += h + g;
        btn("Copy GUI Title JSON", x, y, w, h, m::copyTitleJson, add); y += h + g;
        btn("Save GUI", x, y, half, h, m::saveGui, add);
        btn("Load GUI", x + half + g, y, half, h, m::loadGui, add); y += h + g;
        btn("Clear Queue", x, y, half, h, m::clearQueue, add);
        queue = btn(x + half + g, y, half, h, () -> {}, add);
        queue.active = false;
        y += h + g;
        btn("Resync Inv", x, y, half, h, m::resyncInventory, add);
        btn("Disconnect", x + half + g, y, half, h, m::disconnect, add); y += h + g;
        btn("-", x, y, third / 2, h, () -> { m.spam = Math.max(1, m.spam - 1); refresh(); }, add);
        spam = btn(x + third / 2 + g, y, w - third - 2 * g, h, m::sendQueue, add);
        btn("+", x + w - third / 2, y, third / 2, h, () -> { m.spam = Math.min(100, m.spam + 1); refresh(); }, add); y += h + g;
        btn("Send One", x, y, half, h, m::sendOne, add);
        btn("Pop Last", x + half + g, y, half, h, m::popLast, add); y += h + g + 3 * 16;
        chat = new EditBox(mc.font, x, y, w, h, Component.literal("Chat"));
        chat.setMaxLength(256);
        chat.setHint(Component.literal("Chat..."));
        chat.setResponder(Panel::suggest);
        add.accept(chat);
        refresh();
    }

    /** Key codes are SDL3 scancodes (26.3). Enter sends ("/" = command), Tab applies the first suggestion, PageUp/PageDown walk the sent history. */
    public static boolean onKey(int key) {
        if (chat == null || !chat.isFocused()) return false;
        switch (key) {
            case 40, 88 -> {
                String t = chat.getValue();
                if (!t.isBlank() && mc.getConnection() != null) {
                    if (history.isEmpty() || !history.get(history.size() - 1).equals(t)) history.add(t);
                    hi = history.size();
                    if (t.startsWith("/")) mc.getConnection().sendCommand(t.substring(1));
                    else mc.getConnection().sendChat(t);
                    chat.setValue("");
                }
            }
            case 43 -> { if (!shown.isEmpty()) pick(shown.get(0)); }
            case 75 -> { if (hi > 0) chat.setValue(history.get(--hi)); }
            case 78 -> {
                if (hi < history.size() - 1) chat.setValue(history.get(++hi));
                else { hi = history.size(); chat.setValue(""); }
            }
            default -> { return false; }
        }
        return true;
    }

    private static void suggest(String text) {
        if (!text.startsWith("/") || mc.getConnection() == null) { showSuggestions(text, List.of()); return; }
        var d = mc.getConnection().getCommands();
        String cmd = text.substring(1);
        d.getCompletionSuggestions(d.parse(cmd, mc.getConnection().getSuggestionsProvider()), cmd.length())
            .thenAccept(r -> mc.execute(() -> showSuggestions(text, r.getList())));
    }

    private static void pick(Suggestion s) {
        chat.setValue("/" + s.apply(chat.getValue().substring(1)));
    }

    private static void showSuggestions(String text, List<Suggestion> list) {
        if (chat == null || adder == null || !text.equals(chat.getValue())) return; // stale async result
        sug.forEach(remover);
        sug.clear();
        shown = list.subList(0, Math.min(3, list.size()));
        int y = chat.getY() - 16;
        for (Suggestion s : shown) {
            Button b = Button.builder(Component.literal(s.getText()), bb -> pick(s))
                .bounds(chat.getX(), y, chat.getWidth(), 14).build();
            y -= 16;
            sug.add(b);
            adder.accept(b);
        }
    }

    /** Called every tick; labels only change when state does, and stale buttons are harmless. */
    public static void refresh() {
        UiUtilsModule m = UiUtilsModule.I;
        if (m == null || sync == null || mc.player == null) return;
        sync.setMessage(Component.literal("Sync: " + mc.player.containerMenu.containerId + "  Rev: " + mc.player.containerMenu.getStateId()));
        send.setMessage(Component.literal("Send packets: " + m.sendPackets));
        delay.setMessage(Component.literal("Delay packets: " + m.delayPackets));
        queue.setMessage(Component.literal("Queue: " + m.queue.size()));
        spam.setMessage(Component.literal("Spam (x" + m.spam + ")"));
    }

    private static Button btn(String label, int x, int y, int w, int h, Runnable r, Consumer<AbstractWidget> add) {
        Button b = Button.builder(Component.literal(label), bb -> r.run()).bounds(x, y, w, h).build();
        add.accept(b);
        return b;
    }

    private static Button btn(int x, int y, int w, int h, Runnable r, Consumer<AbstractWidget> add) {
        return btn("", x, y, w, h, r, add);
    }
}
