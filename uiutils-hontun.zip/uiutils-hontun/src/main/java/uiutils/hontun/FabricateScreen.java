package uiutils.hontun;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import net.minecraft.network.HashedStack;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundContainerButtonClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;

import static meteordevelopment.meteorclient.MeteorClient.mc;

/** Builds a container click / button click packet and sends or queues it. A Meteor window, so Hontun themes it. */
public class FabricateScreen extends WindowScreen {
    private boolean click = true;
    private ContainerInput action = ContainerInput.PICKUP;
    private WTextBox sync, rev, slot, button;

    public FabricateScreen(GuiTheme theme) {
        super(theme, "Fabricate packet");
    }

    @Override
    public void initWidgets() {
        AbstractContainerMenu m = mc.player.containerMenu;
        WButton type = add(theme.button("Type: Click Slot")).expandX().widget();
        type.action = () -> { click = !click; type.set(click ? "Type: Click Slot" : "Type: Button Click"); };

        sync = field("Sync ID", m.containerId);
        rev = field("Revision", m.getStateId());
        slot = field("Slot", 0);
        button = field("Button", 0);

        WButton act = add(theme.button("Action: " + action.name())).expandX().widget();
        act.action = () -> {
            ContainerInput[] v = ContainerInput.values();
            action = v[(action.ordinal() + 1) % v.length];
            act.set("Action: " + action.name());
        };

        WHorizontalList row = add(theme.horizontalList()).expandX().widget();
        row.add(theme.button("Send")).expandX().widget().action = () -> UiUtilsModule.I.raw(build());
        row.add(theme.button("Queue")).expandX().widget().action = () -> UiUtilsModule.I.queue.add(build());
    }

    private WTextBox field(String name, int value) {
        WHorizontalList row = add(theme.horizontalList()).expandX().widget();
        row.add(theme.label(name));
        return row.add(theme.textBox(String.valueOf(value), (text, c) -> Character.isDigit(c) || c == '-')).expandX().widget();
    }

    private static int num(WTextBox t) {
        try { return Integer.parseInt(t.get().trim()); } catch (NumberFormatException e) { return 0; }
    }

    private Packet<?> build() {
        if (!click) return new ServerboundContainerButtonClickPacket(num(sync), num(button));
        return new ServerboundContainerClickPacket(num(sync), num(rev), (short) num(slot), (byte) num(button), action,
            new Int2ObjectArrayMap<>(),
            HashedStack.create(mc.player.containerMenu.getCarried(), mc.getConnection().decoratedHashOpsGenenerator()));
    }
}
