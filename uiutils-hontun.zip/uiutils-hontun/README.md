# UI Utils (Hontun) — Meteor addon

Modul Meteor `ui-utils` (kategori Misc). Aktifkan, lalu buka container apa pun (chest, furnace, dll.):
panel tombol muncul di kiri atas. Tombol vanilla otomatis ber-style Hontun; jendela "Fabricate packet"
dan setting modul adalah GUI Meteor sehingga memakai tema Hontun.

Build: taruh `meteor-client-26_3.jar` (yang membawa Hontun) di `libs/`, lalu `gradle build` (JDK 25).
Hasil: `build/libs/uiutils-hontun-1.0.0.jar` -> taruh di folder mods bersama Meteor.
